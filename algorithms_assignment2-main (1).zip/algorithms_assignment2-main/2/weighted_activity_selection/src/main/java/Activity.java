import java.io.*;
import java.util.Arrays;
import java.util.Comparator;

class Activity {
    int start, end, weight;

    public Activity(int start, int end, int weight) {
        this.start = start;
        this.end = end;
        this.weight = weight;
    }
}

