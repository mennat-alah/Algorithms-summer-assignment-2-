# algorithms_assignment2
it contains weighted_activity_selection and huffman 
in weighted_activity_selection it contains 
